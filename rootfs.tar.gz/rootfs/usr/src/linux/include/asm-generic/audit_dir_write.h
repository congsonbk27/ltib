__NR_rename,
__NR_mkdir,
__NR_rmdir,
#ifdef __NR_creat
__NR_creat,
#endif
__NR_link,
__NR_unlink,
__NR_symlink,
__NR_mknod,
#ifdef __NR_mkdirat
__NR_mkdirat,
__NR_mknodat,
__NR_unlinkat,
__NR_renameat,
__NR_linkat,
__NR_symlinkat,
#endif
